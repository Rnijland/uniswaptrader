// src/components/AIAssistant.tsx
import React, { useState, useRef, useEffect } from 'react';
import { Button, Card, Input, Spin, Typography, Select, Space, Divider, Alert, Badge } from 'antd';
import { SendOutlined, RobotOutlined, HistoryOutlined, DatabaseOutlined } from '@ant-design/icons';

const { Title, Text, Paragraph } = Typography;
const { Option } = Select;

// Import your AI services
import AIService from '../services/AIService';
import AIPoolAnalysisService from '../services/AIPoolAnalysisService';
import AIWalletService from '../services/AIWalletService';

// Import your existing services (adjust paths as needed)
import { PoolDataService } from '../exchange/PoolDataService';
import { WalletService } from '../exchange/WalletService';
import { SwapService } from '../exchange/SwapService';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  data?: any;
}

interface AssistantProps {
  poolDataService: PoolDataService;
  walletService: WalletService;
  swapService: SwapService;
}

const AIAssistant: React.FC<AssistantProps> = ({ 
  poolDataService,
  walletService,
  swapService
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'chat' | 'pool-analysis' | 'wallet'>('chat');
  const [selectedPool, setSelectedPool] = useState<string | null>(null);
  const [pools, setPools] = useState<{address: string, name: string}[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Initialize AI services
  const aiService = new AIService(process.env.REACT_APP_CLAUDE_API_KEY || '');
  const aiPoolAnalysisService = new AIPoolAnalysisService(aiService, poolDataService);
  const aiWalletService = new AIWalletService(aiService, walletService, swapService);
  
  // Fetch available pools when component mounts
  useEffect(() => {
    const fetchPools = async () => {
      try {
        const availablePools = await poolDataService.getAvailablePools();
        setPools(availablePools);
      } catch (error) {
        console.error('Failed to fetch pools:', error);
      }
    };
    
    fetchPools();
    
    // Add welcome message
    setMessages([
      {
        id: '1',
        content: 'Hello! I\'m your DEX AI assistant. I can help with pool analysis, wallet management, and answer general questions about trading strategies.',
        sender: 'ai',
        timestamp: new Date()
      }
    ]);
  }, []);
  
  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  // Handle sending a message
  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);
    
    try {
      let response: Message;
      
      if (mode === 'chat') {
        // General chat mode
        const aiResponse = await aiService.query(input);
        response = {
          id: (Date.now() + 1).toString(),
          content: aiResponse,
          sender: 'ai',
          timestamp: new Date()
        };
      } else if (mode === 'pool-analysis' && selectedPool) {
        // Pool analysis mode
        const analysis = await aiPoolAnalysisService.analyzePool(selectedPool, {
          includeHistorical: true,
          includeVolume: true,
          includeLiquidity: true
        });
        
        response = {
          id: (Date.now() + 1).toString(),
          content: `Here's my analysis of the selected pool:\n\n${analysis.analysis.summary}`,
          sender: 'ai',
          timestamp: new Date(),
          data: analysis // Store full analysis for UI rendering
        };
      } else if (mode === 'wallet') {
        // Wallet management mode
        const walletResult = await aiWalletService.createOptimizedWallet({
          tradingStyle: input, // Use user input as trading style preference
        });
        
        response = {
          id: (Date.now() + 1).toString(),
          content: `I've created a wallet optimized for your preferences:\n\n${walletResult.recommendation.explanation}`,
          sender: 'ai',
          timestamp: new Date(),
          data: walletResult // Store full wallet data
        };
      } else {
        // Fallback general response
        response = {
          id: (Date.now() + 1).toString(),
          content: "Please select a pool for analysis or switch to a different mode.",
          sender: 'ai',
          timestamp: new Date()
        };
      }
      
      setMessages(prev => [...prev, response]);
    } catch (error) {
      console.error('AI error:', error);
      
      // Error message
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: `Sorry, I encountered an error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        sender: 'ai',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };
  
  // Render a message based on its type and data
  const renderMessage = (message: Message) => {
    if (message.sender === 'user') {
      return <Text>{message.content}</Text>;
    }
    
    // AI message with pool analysis data
    if (message.data && mode === 'pool-analysis') {
      const analysis = message.data.analysis;
      return (
        <div>
          <Paragraph>{message.content}</Paragraph>
          <Card size="small" title="Detailed Analysis" style={{ marginTop: 10 }}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
              <Card.Grid style={{ width: '48%' }}>
                <Text strong>Liquidity:</Text> {analysis.liquidity.assessment}
                <br />
                <Text>{analysis.liquidity.details}</Text>
              </Card.Grid>
              <Card.Grid style={{ width: '48%' }}>
                <Text strong>Price Analysis:</Text>
                <br />
                <Text>Stability: {analysis.priceAnalysis.stability}</Text>
                <br />
                <Text>Trend: {analysis.priceAnalysis.trend}</Text>
              </Card.Grid>
              <Card.Grid style={{ width: '48%' }}>
                <Text strong>Recommendation:</Text> {analysis.tradingStrategy.recommendation}
                <br />
                <Text>{analysis.tradingStrategy.rationale}</Text>
              </Card.Grid>
              <Card.Grid style={{ width: '48%' }}>
                <Text strong>Risks:</Text>
                <br />
                <Text>Impermanent Loss: {analysis.risks.impermanentLoss}</Text>
                <br />
                <Text>Other Risks: {analysis.risks.otherRisks.join(', ')}</Text>
              </Card.Grid>
            </div>
          </Card>
        </div>
      );
    }
    
    // AI message with wallet data
    if (message.data && mode === 'wallet') {
      const walletData = message.data.recommendation;
      return (
        <div>
          <Paragraph>{message.content}</Paragraph>
          <Card size="small" title="Wallet Configuration" style={{ marginTop: 10 }}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
              <Card.Grid style={{ width: '48%' }}>
                <Text strong>Wallet Type:</Text> {walletData.walletType}
                <br />
                <Text strong>Security Level:</Text> {walletData.securityLevel}
              </Card.Grid>
              <Card.Grid style={{ width: '48%' }}>
                <Text strong>Initial Allocation:</Text>
                <br />
                {walletData.initialAllocation.map((alloc: any, index: number) => (
                  <div key={index}>
                    {alloc.token}: {alloc.percentage}%
                  </div>
                ))}
              </Card.Grid>
              <Card.Grid style={{ width: '48%' }}>
                <Text strong>Trading Strategy:</Text>
                <br />
                <Text>Style: {walletData.tradingStrategy.style}</Text>
                <br />
                <Text>Frequency: {walletData.tradingStrategy.tradingFrequency}</Text>
              </Card.Grid>
              <Card.Grid style={{ width: '48%' }}>
                <Text strong>Risk Management:</Text>
                <br />
                <Text>Max Position: {walletData.riskManagement.maxPositionSize}</Text>
                <br />
                <Text>Stop Loss: {walletData.riskManagement.stopLossSettings}</Text>
              </Card.Grid>
            </div>
          </Card>
        </div>
      );
    }
    
    // Regular text message
    return <Text>{message.content}</Text>;
  };
  
  return (
    <Card 
      title={
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <RobotOutlined style={{ marginRight: 8 }} />
          <span>DEX AI Assistant</span>
          {loading && <Spin size="small" style={{ marginLeft: 10 }} />}
        </div>
      }
      style={{ width: '100%', marginTop: 20 }}
    >
      {/* Mode selector */}
      <div style={{ marginBottom: 16 }}>
        <Space>
          <Text strong>Mode:</Text>
          <Select
            value={mode}
            onChange={setMode}
            style={{ width: 150 }}
          >
            <Option value="chat">General Chat</Option>
            <Option value="pool-analysis">Pool Analysis</Option>
            <Option value="wallet">Wallet Creation</Option>
          </Select>
          
          {mode === 'pool-analysis' && (
            <Select
              placeholder="Select a pool to analyze"
              style={{ width: 200 }}
              onChange={setSelectedPool}
              value={selectedPool}
            >
              {pools.map(pool => (
                <Option key={pool.address} value={pool.address}>
                  {pool.name}
                </Option>
              ))}
            </Select>
          )}
        </Space>
      </div>
      
      {/* Mode description */}
      {mode === 'pool-analysis' && (
        <Alert
          message="Pool Analysis Mode"
          description="Ask questions about the selected pool's performance, risks, and trading opportunities."
          type="info"
          showIcon
          style={{ marginBottom: 16 }}
        />
      )}
      
      {mode === 'wallet' && (
        <Alert
          message="Wallet Creation Mode"
          description="Describe your trading preferences and I'll create an optimized wallet configuration."
          type="info"
          showIcon
          style={{ marginBottom: 16 }}
        />
      )}
      
      {/* Messages container */}
      <div
        style={{
          height: 400,
          overflowY: 'auto',
          padding: '0 16px',
          marginBottom: 16,
          border: '1px solid #f0f0f0',
          borderRadius: 4,
          backgroundColor: '#fafafa'
        }}
      >
        {messages.map(msg => (
          <div
            key={msg.id}
            style={{
              marginBottom: 16,
              textAlign: msg.sender === 'user' ? 'right' : 'left'
            }}
          >
            <Badge
              count={msg.sender === 'user' ? 'You' : 'AI'}
              style={{
                backgroundColor: msg.sender === 'user' ? '#1890ff' : '#52c41a'
              }}
            />
            <Card
              size="small"
              style={{
                maxWidth: '80%',
                display: 'inline-block',
                textAlign: 'left',
                backgroundColor: msg.sender === 'user' ? '#e6f7ff' : '#fff'
              }}
            >
              {renderMessage(msg)}
            </Card>
            <div>
              <Text type="secondary" style={{ fontSize: 12 }}>
                {msg.timestamp.toLocaleTimeString()}
              </Text>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Input area */}
      <div style={{ display: 'flex' }}>
        <Input
          placeholder={
            mode === 'chat' 
              ? "Ask me anything about DEX trading..." 
              : mode === 'pool-analysis' 
                ? "Ask about this pool's performance, risks, or opportunities..." 
                : "Describe your trading style (e.g., 'aggressive', 'conservative', 'focus on stablecoins')..."
          }
          value={input}
          onChange={e => setInput(e.target.value)}
          onPressEnter={handleSend}
          disabled={loading || (mode === 'pool-analysis' && !selectedPool)}
          style={{ marginRight: 8 }}
        />
        <Button
          type="primary"
          icon={<SendOutlined />}
          onClick={handleSend}
          disabled={loading || !input.trim() || (mode === 'pool-analysis' && !selectedPool)}
        >
          Send
        </Button>
      </div>
    </Card>
  );
};

export default AIAssistant;