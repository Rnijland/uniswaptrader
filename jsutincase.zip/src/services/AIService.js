// services/AIService.js
class AIService {
  constructor(apiKey, model = "claude-3-sonnet-20240229") {
    this.apiKey = apiKey;
    this.model = model;
    this.baseUrl = "https://api.anthropic.com/v1/messages";
    this.maxRetries = 3;
  }

  async query(promptContent, options = {}) {
    const { 
      systemPrompt = null,
      maxTokens = 1000,
      temperature = 0.7,
      retries = this.maxRetries,
      parseJSON = false
    } = options;
    
    let attempt = 0;
    let lastError = null;
    
    const messages = [{ role: "user", content: promptContent }];
    
    while (attempt < retries) {
      try {
        const requestBody = {
          model: this.model,
          max_tokens: maxTokens,
          temperature: temperature,
          messages: messages
        };
        
        if (systemPrompt) {
          requestBody.system = systemPrompt;
        }
        
        // For JSON responses, add specific instruction
        if (parseJSON) {
          requestBody.system = (systemPrompt ? systemPrompt + "\n\n" : "") + 
            "Please provide your response as valid JSON. Don't include any text outside the JSON object.";
        }
        
        const response = await fetch(this.baseUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': this.apiKey,
            'anthropic-version': '2023-06-01'
          },
          body: JSON.stringify(requestBody)
        });
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(`API Error: ${response.status} - ${JSON.stringify(errorData)}`);
        }
        
        const result = await response.json();
        let content = result.content[0].text;
        
        if (parseJSON) {
          try {
            // Extract JSON from the response if it's wrapped in backticks
            if (content.includes('```json')) {
              content = content.split('```json')[1].split('```')[0].trim();
            } else if (content.includes('```')) {
              content = content.split('```')[1].split('```')[0].trim();
            }
            return JSON.parse(content);
          } catch (jsonError) {
            console.error("Failed to parse JSON from AI response:", jsonError);
            console.log("Raw response:", content);
            throw new Error("Failed to parse JSON from AI response");
          }
        }
        
        return content;
      } catch (error) {
        lastError = error;
        console.error(`AI Service attempt ${attempt + 1} failed:`, error);
        attempt++;
        
        if (attempt < retries) {
          // Exponential backoff
          const delay = 1000 * Math.pow(2, attempt);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }
    
    throw lastError || new Error("Failed to get response from AI service");
  }
}

export default AIService;