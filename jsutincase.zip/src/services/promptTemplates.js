// services/promptTemplates.js

/**
 * Generate a prompt for pool analysis
 */
export function poolAnalysisPrompt(poolData, additionalData = {}, options = {}) {
    return `
  Analyze the following DEX liquidity pool:
  
  POOL DATA:
  ${JSON.stringify(poolData, null, 2)}
  
  ${additionalData.historicalPrices ? `HISTORICAL PRICES:\n${JSON.stringify(additionalData.historicalPrices, null, 2)}\n` : ''}
  ${additionalData.volumeData ? `VOLUME DATA:\n${JSON.stringify(additionalData.volumeData, null, 2)}\n` : ''}
  ${additionalData.liquidityHistory ? `LIQUIDITY HISTORY:\n${JSON.stringify(additionalData.liquidityHistory, null, 2)}\n` : ''}
  
  Please provide a comprehensive analysis including:
  1. Liquidity assessment
  2. Price stability and volatility
  3. Volume and trading activity
  4. Impermanent loss risk
  5. Trading opportunities
  6. ${options.focus === "graduation" ? "Proximity to graduation threshold" : "Overall opportunity rating (1-10)"}
  ${options.additionalAnalysis ? `7. ${options.additionalAnalysis}` : ''}
  
  Format your response as a JSON object with the following structure:
  {
    "summary": "Brief 1-2 sentence overview",
    "liquidity": {
      "assessment": "High/Medium/Low",
      "details": "Detailed explanation",
      "trend": "Increasing/Stable/Decreasing"
    },
    "priceAnalysis": {
      "stability": "High/Medium/Low",
      "volatility": "Percentage or description",
      "trend": "Bullish/Bearish/Neutral",
      "support": "Key support level if identifiable",
      "resistance": "Key resistance level if identifiable"
    },
    "tradingActivity": {
      "volume": "High/Medium/Low",
      "swapFrequency": "High/Medium/Low",
      "largeMovements": "Any notable large trades"
    },
    "risks": {
      "impermanentLoss": "High/Medium/Low",
      "poolConcentration": "High/Medium/Low",
      "otherRisks": ["List any other identified risks"]
    },
    ${options.focus === "graduation" ? 
      `"graduationAnalysis": {
        "currentStage": "Current stage in bonding curve",
        "proximityToGraduation": "Percentage or description",
        "estimatedTimeToGraduation": "Estimated time if predictable",
        "recommendedAction": "Buy/Sell/Hold/Monitor"
      },` : 
      `"opportunityRating": 7,`
    }
    "tradingStrategy": {
      "recommendation": "Buy/Sell/Hold/Provide Liquidity",
      "entryPoints": ["Specific conditions for entry"],
      "exitPoints": ["Specific conditions for exit"],
      "rationale": "Explanation of the strategy"
    },
    "additionalInsights": ["Any other observations"]
  }
  
  ${options.additionalInstructions ? options.additionalInstructions : ''}
  `;
  }
  
  /**
   * Generate a prompt for wallet creation
   */
  export function walletCreationPrompt(userPreferences = {}, marketContext = null) {
    return `
  Create an optimized wallet configuration for DEX trading with the following requirements:
  
  USER PREFERENCES:
  ${JSON.stringify(userPreferences, null, 2)}
  
  ${marketContext ? `MARKET CONTEXT:\n${JSON.stringify(marketContext, null, 2)}\n` : ''}
  
  Please provide a comprehensive wallet configuration and strategy including:
  1. Wallet type and security features
  2. Initial token allocation
  3. Gas optimization settings
  4. Trading automation parameters
  5. Risk management settings
  
  Format your response as a JSON object with the following structure:
  {
    "name": "Suggested wallet name",
    "walletType": "HD Wallet/Multi-sig/etc",
    "securityLevel": "High/Medium/Low",
    "securityRecommendations": ["List of security recommendations"],
    "initialAllocation": [
      {
        "token": "ETH",
        "percentage": 70,
        "rationale": "Explanation"
      },
      {
        "token": "USDC",
        "percentage": 30,
        "rationale": "Explanation"
      }
    ],
    "gasStrategy": {
      "priorityLevel": "High/Medium/Low",
      "maxGasPrice": "Recommended maximum gas price",
      "timingRecommendation": "When to execute transactions"
    },
    "tradingStrategy": {
      "style": "Active/Passive/Mixed",
      "tradingFrequency": "High/Medium/Low",
      "focusTokens": ["List of recommended tokens to focus on"],
      "avoidTokens": ["List of tokens to avoid"]
    },
    "riskManagement": {
      "maxPositionSize": "Recommended max position as percentage",
      "stopLossSettings": "Recommended stop loss percentage",
      "diversificationLevel": "High/Medium/Low"
    },
    "explanation": "Overall explanation of wallet strategy"
  }
  `;
  }
  
  /**
   * Generate a prompt for wallet analysis
   */
  export function walletAnalysisPrompt(walletAddress, walletData, transactionHistory) {
    return `
  Analyze this wallet's performance for DEX trading:
  
  WALLET ADDRESS: ${walletAddress}
  
  WALLET DATA:
  ${JSON.stringify(walletData, null, 2)}
  
  TRANSACTION HISTORY:
  ${JSON.stringify(transactionHistory, null, 2)}
  
  Please provide a comprehensive analysis including:
  1. Overall performance assessment
  2. Trade efficiency analysis
  3. Gas usage optimization
  4. Risk exposure evaluation
  5. Improvement recommendations
  
  Format your response as a JSON object with the following structure:
  {
    "summary": "Brief 1-2 sentence overview",
    "performanceMetrics": {
      "overallReturn": "Calculated return rate",
      "bestTrade": "Details of best performing trade",
      "worstTrade": "Details of worst performing trade",
      "averageTradeReturn": "Average return per trade"
    },
    "tradeEfficiency": {
      "timingAnalysis": "Analysis of trade timing",
      "slippageImpact": "Analysis of slippage impact on trades",
      "missedOpportunities": ["Any significant missed opportunities"]
    },
    "gasAnalysis": {
      "totalGasSpent": "Total gas spent in base currency",
      "averageGasPerTrade": "Average gas per trade",
      "optimizationSuggestions": ["Suggestions for gas optimization"]
    },
    "riskAnalysis": {
      "portfolioDiversification": "High/Medium/Low",
      "largestExposures": ["List of largest token exposures"],
      "volatilityExposure": "High/Medium/Low"
    },
    "recommendations": [
      "Specific, actionable recommendations for improvement"
    ]
  }
  `;
  }