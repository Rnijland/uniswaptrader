// services/AIPoolAnalysisService.js
import AIService from './AIService';
import { poolAnalysisPrompt } from './promptTemplates';

class AIPoolAnalysisService {
  constructor(aiService, poolDataService) {
    this.aiService = aiService;
    this.poolDataService = poolDataService;
  }
  
  /**
   * Analyze a liquidity pool using AI
   * @param {string} poolAddress - The address of the pool to analyze
   * @param {Object} options - Analysis options
   * @returns {Object} Analysis results and pool data
   */
  async analyzePool(poolAddress, options = {}) {
    try {
      // Fetch pool data using your existing service
      const poolData = await this.poolDataService.getPoolData(poolAddress);
      
      // Get additional data if needed
      let additionalData = {};
      
      if (options.includeHistorical) {
        additionalData.historicalPrices = await this.poolDataService.getHistoricalPrices(
          poolAddress, 
          options.timeframe || "7d"
        );
      }
      
      if (options.includeVolume) {
        additionalData.volumeData = await this.poolDataService.getVolumeData(
          poolAddress, 
          options.timeframe || "7d"
        );
      }
      
      if (options.includeLiquidity) {
        additionalData.liquidityHistory = await this.poolDataService.getLiquidityHistory(
          poolAddress, 
          options.timeframe || "7d"
        );
      }
      
      // Format the prompt with all data
      const prompt = poolAnalysisPrompt(poolData, additionalData, options);
      
      // Get analysis from Claude
      const analysis = await this.aiService.query(prompt, {
        parseJSON: true,
        systemPrompt: "You are an expert in DeFi and DEX analytics. Provide detailed analysis on liquidity pools, trading opportunities, and investment strategies.",
        maxTokens: 1500
      });
      
      // Save analysis to database if needed
      if (options.saveToDatabase && this.databaseService) {
        await this.databaseService.savePoolAnalysis(poolAddress, analysis);
      }
      
      return {
        poolData,
        analysis,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error("Pool analysis failed:", error);
      throw new Error(`Failed to analyze pool: ${error.message}`);
    }
  }
  
  /**
   * Compare multiple pools to find the best trading opportunity
   * @param {Array<string>} poolAddresses - List of pool addresses to compare
   * @param {Object} criteria - Comparison criteria (e.g. liquidity, volume, etc.)
   * @returns {Object} Ranked pools with analysis
   */
  async comparePoolsForTrading(poolAddresses, criteria = {}) {
    try {
      // Get data for all pools
      const poolsData = await Promise.all(
        poolAddresses.map(address => this.poolDataService.getPoolData(address))
      );
      
      // Generate a specialized prompt for pool comparison
      const prompt = `
Compare the following DEX pools and recommend the best trading opportunity:

POOLS DATA:
${JSON.stringify(poolsData, null, 2)}

COMPARISON CRITERIA:
${JSON.stringify(criteria, null, 2)}

Please rank these pools for trading, considering:
1. Liquidity depth and stability
2. Volume and trading activity
3. Price impact for typical trades
4. Opportunities based on token fundamentals
5. Historical performance patterns

Provide a detailed comparison with specific strengths and weaknesses of each pool.
`;
      
      // Get analysis from Claude
      const comparison = await this.aiService.query(prompt, {
        parseJSON: true,
        systemPrompt: "You are an expert in identifying optimal trading opportunities across multiple DEX pools. Provide detailed comparative analysis and clear recommendations.",
        maxTokens: 2000
      });
      
      return {
        pools: poolsData,
        comparison,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error("Pool comparison failed:", error);
      throw new Error(`Failed to compare pools: ${error.message}`);
    }
  }
}

export default AIPoolAnalysisService;