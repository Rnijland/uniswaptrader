import { Router } from 'express';

/**
 * Express router for filter API endpoints
 */
declare const router: Router;

export = router;
