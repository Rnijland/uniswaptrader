import { Router } from 'express';

/**
 * Express router for filter view endpoints
 */
declare const router: Router;

export = router;
