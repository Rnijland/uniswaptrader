/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./src/ui/views/**/*.ejs"],
    theme: {
      extend: {},
    },
    plugins: [],
  }