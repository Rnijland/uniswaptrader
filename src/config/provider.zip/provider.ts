// src/config/provider.ts
import { ethers } from 'ethers';
import dotenv from 'dotenv';
import { logger } from '../utils/logger';

dotenv.config();

// Environment variables
const INFURA_API_KEY = process.env.INFURA_API_KEY;
const ETHEREUM_NETWORK = process.env.ETHEREUM_NETWORK || 'mainnet';
const WS_ENDPOINT = process.env.WS_ENDPOINT || `wss://${ETHEREUM_NETWORK}.infura.io/ws/v3/${INFURA_API_KEY}`;

// Create providers with auto-reconnect capabilities
export const createJsonRpcProvider = (): ethers.JsonRpcProvider => {
  const provider = new ethers.JsonRpcProvider(
    `https://${ETHEREUM_NETWORK}.infura.io/v3/${INFURA_API_KEY}`
  );
  
  logger.info('JSON-RPC provider initialized');
  return provider;
};

export const createWebSocketProvider = (): ethers.WebSocketProvider => {
  if (!INFURA_API_KEY) {
    throw new Error('INFURA_API_KEY is not defined in .env file');
  }

  const provider = new ethers.WebSocketProvider(WS_ENDPOINT);
  
  // Handle WebSocket disconnections
  // In Ethers.js v6, it's 'websocket' not '_websocket'
  provider.websocket.onclose = (event: CloseEvent) => {
    logger.warn(`WebSocket connection closed with code ${event.code}. Reconnecting...`);
    setTimeout(() => {
      // Recreate the provider
      createWebSocketProvider();
    }, 3000); // Retry after 3 seconds
  };

  provider.websocket.onerror = (event: Event) => {
    logger.error(`WebSocket error: ${event.type}`);
  };

  logger.info('WebSocket provider initialized');
  return provider;
};

// Default provider for general use
export const jsonRpcProvider = createJsonRpcProvider();
export const wsProvider = createWebSocketProvider();